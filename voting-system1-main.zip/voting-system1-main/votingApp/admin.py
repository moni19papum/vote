from django.contrib import admin
from .models import number1,aadhaarnumber,voteringlist,votedata
# Register your models here.

admin.site.register(number1)
admin.site.register(aadhaarnumber)
admin.site.register(voteringlist)
admin.site.register(votedata)